from pathlib import Path

print("Recovered stream fragment:\n")

print(Path("output.txt").read_text())

print("\nEncrypted secret:\n")

print(Path("ciphertext.txt").read_text())