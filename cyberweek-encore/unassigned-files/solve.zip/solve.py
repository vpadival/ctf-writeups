import hashlib
with open("flags.txt") as f:
    for line in f:
        flag = line.strip()
        h = hashlib.sha256(flag._____()).hexdigest()
        if h.startswith("00__0"):
            print(flag, h)