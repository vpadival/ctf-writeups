=========================================================
 VERTEX DYNAMICS — INTERNAL INCIDENT RESPONSE ARCHIVE
 Classification: INTERNAL / DO NOT DISTRIBUTE
 Case Ref: VD-IR-2026-0814
=========================================================

On the morning of 2026-08-15, the Floor 47 R&D lab (home of
"Project Chimera", our next-gen materials research) reported
that the master specification document was missing from the
document management system and a partial copy had been found
circulating on a competitor's internal Slack (screenshot
forwarded anonymously to Legal — don't ask how).

IT Security has pulled every log we have access to for the
72 hours surrounding the incident. It's messy. Floor 47 has
40 badge-holders, half of them pull all-nighters as a matter
of pride, and our VPN concentrator logs everything, including
a lot of noise from automated service accounts.

Your job: figure out who actually took it, and prove it with
evidence that survives cross-examination — not vibes.

Work through:
  laptop/       - artifacts pulled from a forensic image of a
                  suspect workstation (browser + shell history,
                  a recovered file from the recycle bin, and a
                  personal notes file)
  emails/       - mailbox exports for several Floor 47 staff
                  (not all of it is relevant. some of it is
                  just Tuesday.)
  badge_logs/   - physical access control logs for Floor 47
  vpn/          - VPN concentrator session logs + the standing
                  alert list IT Security already triages daily
  documents/    - the DMS access log for the stolen file, plus
                  a draft incident report and a locked archive
                  IT found sitting in a home directory

Answer the questions in CHALLENGE_BRIEF.md (given to you
separately). The final flag format is cyberweek{...}

Good luck. Try not to accuse Lisa in Facilities again, HR is
still mad about last time.
   — A. Romero, CISO
